/**
 * On crée la variable qui contiendra le nom du groupe de graphique du dashboard
 */
const groupName = "dataset";

/**
 * Fonction pour reset les filtres et redessiner les graphiques
 */
function reset() {
    dc.filterAll(groupName);
    dc.renderAll(groupName);
}

/**
 * Permet de montrer les % des tranches du pie chart
 * @param chart Le pie chart sur quoi faire la modification
 */
const montrerPourcentagesPieChart = (chart) => {
    chart.selectAll('text.pie-slice').text(function (d) {
        if (((d.endAngle - d.startAngle) / (2 * Math.PI) * 100) !== 0) {
            return dc.utils.printSingleValue(Math.round((d.endAngle - d.startAngle) / (2 * Math.PI) * 100)) + '%';
        }
    })
}

/**
 * La fonction pour créer la visualisation
 */
async function createDataViz() {

    // On récupère le dataset et on le met dans la variable dataset
    let dataset = await d3.csv("/data/survey.csv");

    //const selectedRows = dataset.filter(row => row.Age === 18);



    // On formate un peu la donnée pour nous éviter des soucis
    dataset.forEach((d) => {

        d["While working"] = d["While working"] === "Yes";
        d["Instrumentalist"] = d["Instrumentalist"] === "Yes";
        d["Composer"] = d["Composer"] === "Yes";
        d["Exploratory"] = d["Exploratory"] === "Yes";
        d["Foreign languages"] = d["Foreign languages"] === "Yes";
        d["While working"] = d["While working"] === "Yes";
        d["Fav genre"] = d["Latin"]


        d["Age"] = +d["Age"];
        d["Hours per day"] = +d["Hours per day"];
        d["BPM"] = +d["BPM"];
        d["Anxiety"] = +d["Anxiety"];
        d["Depression"] = +d["Depression"];
        d["Insomnia"] = +d["Insomnia"];
        d["OCD"] = +d["OCD"];

        d["Timestamp"] = new Date(d["Timestamp"]);
    });




    var chart1 = dc.pieChart('#chart1', groupName);
    var chart2 = dc.barChart('#chart2', groupName);
    var chart3 = dc.compositeChart('#chart3', groupName);
    var chart4 = dc.scatterPlot('#chart4', groupName);
    var chart5 = dc.seriesChart('#chart5', groupName);


    var mycrossfilter = crossfilter(dataset);

    mycrossfilter.add(dataset.map(function (data) {
        return {
            Anxiety: data["Hours per day"],
            Yes: data["While working"] == 'Yes' ? 1 : 0,
            No: data["While working"] == 'No' ? 0 : 1
        };
    }));

    var dim = mycrossfilter.dimension(dc.pluck('Anxiety')),

        grp1 = dim.group().reduceSum(dc.pluck('Yes')),
        grp2 = dim.group().reduceSum(dc.pluck('No'));

    dataset.forEach(function (x) {
        if (x["While working"] == 'Yes') {
            x.newdata = 1;
        } else {
            x.newdata = 2;
        }
    });

    var hwDimension1 = mycrossfilter.dimension(function (dataset) {
        return [dataset["While working"], dataset["Anxiety"]];
    });
    var hwGroup1 = hwDimension1.group().reduceCount();

    //
    var SDimension = mycrossfilter.dimension(function (dataset) {
        return dataset["Primary streaming service"];
    });
    var SGroup = SDimension.group().reduceCount();

    //

    var ageDimension = mycrossfilter.dimension(function (dataset) {
        return dataset["Age"];
    });
    var ageGroup = ageDimension.group().reduceCount();

    //

    var ADimension = mycrossfilter.dimension(function (dataset) {
        return dataset["Age"];
    });
    var AGroup = ADimension.group().reduceCount();

    //

    var hwDimension = mycrossfilter.dimension(function (data) {
        return [Math.floor(data["Age"]), Math.floor(data["Hours per day"])];
    });
    var hwGroup = hwDimension.group().reduceCount();


    chart1
        .width(500)
        .height(220)
        .dimension(SDimension)
        .group(SGroup)
        .on('renderlet', function (chart1) {
            montrerPourcentagesPieChart(chart1);
        });

    //
    chart2
        .width(400)
        .height(220)
        .x(d3.scaleLinear().domain([15, 70]))
        .brushOn(false)
        .yAxisLabel("Count")
        .xAxisLabel("Age")
        .dimension(ageDimension)
        .group(ageGroup)
        .on('renderlet', function (chart2) {
            chart2.selectAll('rect').on('click', function (d) {
                console.log('click!', d);
            });
        });


    chart3
        .width(400)
        .height(220)
        .x(d3.scaleLinear().domain([0, 25]))
        .yAxisLabel("Count")
        .xAxisLabel("Anxiety")
        .legend(dc.legend().x(80).y(20).itemHeight(13).gap(5))
        .renderHorizontalGridLines(true)
        .compose([
            dc.lineChart(chart3)
                .dimension(dim)
                .colors('red')
                .group(grp1, "Yes")
                .dashStyle([2, 2]),
            dc.lineChart(chart3)
                .dimension(dim)
                .colors('blue')
                .group(grp2, "No")
                .dashStyle([5, 5])
        ])
        .brushOn(false)

    chart4
        .width(400)
        .height(230)
        .x(d3.scaleLinear().domain([10, 90]))
        .y(d3.scaleLinear().domain([0, 25]))
        .brushOn(false)
        .xAxisLabel("Age")
        .yAxisLabel("Hours per day")
        .symbolSize(5)
        .clipPadding(10)
        .dimension(hwDimension)
        .group(hwGroup);

        
    chart5
        .width(430)
        .height(220)
        .chart(function (c) {
            return dc.lineChart(c).interpolate('cardinal').evadeDomainFilter(true);
        })
        .x(d3.scaleLinear().domain([0, 25]))
        .elasticY(true)
        .brushOn(false)
        .xAxisLabel("Anxiety")
        .yAxisLabel("")
        .dimension(hwDimension1)
        .group(hwGroup1)
        .seriesAccessor(function (d) { return d.key[0]; })
        .keyAccessor(function (d) { return +d.key[1]; })
        .valueAccessor(function (d) { return +d.value; })
        .legend(dc.legend().x(350).y(100).itemHeight(13).gap(3).horizontal(1)
        .legendWidth(100).itemWidth(60));



    // On veut rendre tous les graphiques qui proviennent du chart group "dataset"
    dc.renderAll(groupName);





}